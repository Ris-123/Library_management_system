<?php
 session_start();
 include('db.php');
 if(!isset($_SESSION['usr'])){
    $profile = '';
    $registration = '<button class="btn btn-default ms-lg-3" type="button" onclick="registr()"><i class="fa fa-user"></i>
    Register Now</button>';
 }
 else{
    $profile = '<li class="nav-item active">
    <a class="nav-link" href="profile.php"><i class="fa fa-user"></i> My Profile</a>
</li>';
    $registration = '<a href="logout.php" class="btn btn-default ms-lg-3" type="button"><i class="fa fa-signout"></i>
    Log Out</a>';
 }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Easy Library</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/main.css">
</head>

<body>
    <nav class="navbar navbar-expand-sm bg-light navbar-light sticky-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Easy Library</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php"><i class="fa fa-home"></i> Home</a>
                    </li>
                    <?php echo $profile; ?>
                    <li class="nav-item active">
                        <a class="nav-link" href="contact_us.php"><i class="fa fa-phone"></i> Contact Us</a>
                    </li>
                </ul>
                <?php echo $registration; ?>
                
            </div>
        </div>
    </nav>

    <div class="banner-area py-5">
        <div class="container">
            <div class="page-banner-content">
                <h2 class="text-center">Sign-up</h2>
                <ul class="list-inline w-100 mx-auto">
                    <li class="list-inline-item">
                        <a class="text-decoration-none text-light" href="index.php">Home</a>
                    </li>
                    <li class="list-inline-item"> Sign-up</li>
                </ul>
            </div>
        </div>
    </div>

    <div class="register-area py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="px-4">
                        <img src="https://edmy-react.hibootstrap.com/images/register-img.png" class="img-fluid"
                            alt="Image">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="register-form">
                        <h2 class="mb-4">Create your account</h2>

                        <ul class="nav nav-pills justify-content-between mb-3">
                            <li class="nav-item">
                                <a class="nav-link active" data-bs-toggle="pill" href="#home">Login</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" data-bs-toggle="pill" href="#menu1">Register</a>
                            </li>
                        </ul>

                        <!-- Tab panes -->
                        <div class="tab-content mt-3">
                            <div class="tab-pane active" id="home">
                                <form class="w-100" action="action.php" method="post">
                                    <div class="form-group mb-3">
                                        <input type="text" class="form-control form-control-lg" placeholder="Email"
                                            name="email">
                                    </div>
                                    <div class="form-group mb-3">
                                        <input type="password" class="form-control form-control-lg"
                                            placeholder="Password" name="password">
                                    </div>
                                    <button  type="submit" class="btn btn-default btn-lg w-100 mt-3">Login Now</button>
                                </form>
                            </div>
                            <div class="tab-pane fade" id="menu1">
                                <form class="w-100" action="action.php" method="post">
                                    <div class="form-group mb-3">
                                        <input type="text" class="form-control form-control-lg" placeholder="First Name"
                                            name="first_name">
                                    </div>
                                    <div class="form-group mb-3">
                                        <input type="text" class="form-control form-control-lg" placeholder="Last Name"
                                            name="last_name">
                                    </div>
                                    <div class="form-group mb-3">
                                        <input type="email" class="form-control form-control-lg" placeholder="Email"
                                            name="email">
                                    </div>
                                    <div class="form-group mb-3">
                                        <input type="password" class="form-control form-control-lg"
                                            placeholder="Password" name="password">
                                    </div>
                                    <button type="submit" class="btn btn-default btn-lg w-100 mt-3">Register
                                        Now</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <footer class="bg-dark pt-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-6 col-12 text-light">
                    <h5>EasyTutorial</h5>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mattis mi suscipit bibendum sit amet,
                        consectetur.</p>
                </div>
                <div class="col-lg-3 col-sm-6 col-12 text-light">
                    <h5>Quick Link</h5>
                    <ul class="list-unstyled">
                        <li class="">Courses</li>
                        <li class="">About Us</li>
                        <li class="">Terms & Conditions</li>
                    </ul>
                </div>
                <div class="col-lg-3 col-sm-6 col-12 text-light">
                    <h5>Help Center</h5>
                    <ul class="list-unstyled">
                        <li class="">Support</li>
                        <li class="">Get Help</li>
                        <li class="">Privacy Policy</li>
                    </ul>
                </div>
                <div class="col-lg-3 col-sm-6 col-12 text-light">
                    <h5>Contact Info</h5>
                    <ul class="list-unstyled">
                        <li class="">Call Us: +91-8906634065</li>
                        <li class="">Address: 105/5b, Dumdum road, Kolkata-74</li>
                        <li class="">Mail Us: support@softmaker.co.in</li>
                    </ul>
                </div>
                <hr>
                <p class="text-light text-center">EasyLibrary &copy; 2023</p>
            </div>
        </div>
    </footer>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/common.js"></script>
</body>

</html>