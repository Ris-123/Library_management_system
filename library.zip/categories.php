<?php
session_start();
include('db.php');
if (!isset($_SESSION['usr'])) {
    $profile = '';
    $registration = '<button class="btn btn-default ms-lg-3" type="button" onclick="registr()"><i class="fa fa-user"></i>
    Register Now</button>';
} else {
    $profile = '<li class="nav-item active">
    <a class="nav-link" href="profile.php"><i class="fa fa-user"></i> My Profile</a>
</li>';
    $registration = '<a href="logout.php" class="btn btn-default ms-lg-3" type="button"><i class="fa fa-signout"></i>
    Log Out</a>';
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Easy Library</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.3/css/bootstrap.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/main.css">

    <style>
        .item-img-wrap {
            position: relative;
            text-align: center;
            overflow: hidden;
        }

        .navbar-light .navbar-nav .active>.nav-link {
            color: #0c757a;
        }

        .item-img-wrap img {
            -moz-transition: all 200ms linear;
            -o-transition: all 200ms linear;
            -webkit-transition: all 200ms linear;
            transition: all 200ms linear;
            width: 100%;
        }

        .item-img-overlay {
            position: absolute;
            width: 100%;
            height: 100%;
            left: 0;
            top: 0;
        }

        .item-img-wrap:hover .item-img-overlay span {
            opacity: 1;
        }

        .item-img-wrap:hover img {
            -moz-transform: scale(1.1);
            -o-transform: scale(1.1);
            -ms-transform: scale(1.1);
            -webkit-transform: scale(1.1);
            transform: scale(1.1);
        }

        .theme {
            background: linear-gradient(133.65deg, #098b99 2.24%, #6cc17e);
        }

        .theme:hover {
            background: linear-gradient(133.65deg, #6cc17e 2.24%, #098b99);
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-sm bg-light navbar-light sticky-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Easy Library</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="collapsibleNavbar">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php"><i class="fa fa-home"></i> Home</a>
                    </li>
                    <?php echo $profile; ?>
                    <li class="nav-item active">
                        <a class="nav-link" href="contact_us.php"><i class="fa fa-phone"></i> Contact Us</a>
                    </li>
                </ul>
                <?php echo $registration; ?>

            </div>
        </div>
    </nav>


    <div class="container py-2">
        <h4>
            <ul class="nav nav-tabs">
                <li class="nav-item theme col-md-2 ms-5">
                    <a class="theme nav-link text-light" data-toggle="tab" href="#Detective">Detective Books</a>
                </li>
                <li class="nav-item theme col-md-2 ms-5 ">
                    <a class="nav-link text-light" data-toggle="tab" href="#Fairytale">Fairy-tale Books</a>
                </li>
                <li class="nav-item theme col-md-2 ms-5">
                    <a class="nav-link text-light" data-toggle="tab" href="#bca">BCA Books</a>
                </li>
                <li class="nav-item theme col-md-2 ms-5">
                    <a class="nav-link text-light" data-toggle="tab" href="#Sciencefiction">Science Fiction</a>
                </li>
            </ul>
        </h4>
    </div>

    <div class="container-fluid">
        <div class="tab-content">
            <div id="Detective" role="tabpanel" class="tab-pane fade in active">
                <div class="alert alert-info">
                    <div class="row">
                        <div class="col-md-12">
                            <div id="grid" class="row">
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap ">
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTg_PLHspNMgc12hJVXUOw7f2s66CgsHxmdTA&usqp=CAU"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">The Sherlock Effect
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap ">
                                        <img src="https://images-na.ssl-images-amazon.com/images/I/81zfi0ktLzL._AC_UL210_SR210,210_.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">The Tower of London
                                                        Puzzle Book</h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap ">
                                        <img src="https://images-na.ssl-images-amazon.com/images/I/81kU1R264VL._AC_UL750_SR750,750_.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">Not Getting Murdered
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap ">
                                        <img src="https://images-eu.ssl-images-amazon.com/images/I/81E+C6YZucL._AC_UL232_SR232,232_.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">An English Murderer
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap ">
                                        <img src="https://www.theworks.co.uk/dw/image/v2/BDXF_PRD/on/demandware.static/-/Sites-master-catalog-tws-uk/default/dw3d544c1b/9781800326095_Z.jpg?sw=200&sh=200&sm=fit"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">Murderer At The House
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap ">
                                        <img src="https://images-eu.ssl-images-amazon.com/images/I/91BLYNjIBwL._AC_UL232_SR232,232_.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">Murderer Most Puzzling
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap ">
                                        <img src="https://images-na.ssl-images-amazon.com/images/I/71jalf8FcZL._AC_UL600_SR600,600_.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">The Murderer Of
                                                        Mr.Twist</h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap ">
                                        <img src="https://images-na.ssl-images-amazon.com/images/I/81o0awzRooL._AC_UL600_SR600,600_.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">The Midtown Murderers
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                            </div><!--grid-->
                        </div>
                    </div>
                </div>
            </div>
            <div id="Fairytale" role="tabpanel" class="tab-pane fade">
                <div class="alert alert-info">
                    <div class="row">
                        <div class="col-md-12">
                            <div id="grid" class="row">
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://m.media-amazon.com/images/I/91h68AvGtaL.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">The Random House of
                                                        Fairy Tales</h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://pictures.abebooks.com/inventory/30304437575.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">My Book of Fairy
                                                        Tables and Fables</h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://pictures.abebooks.com/inventory/9631103087.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">The Ladybird Book of
                                                        Fairy Tales</h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRxlOOG930yBl_KYncZDLCsy1RyYb4G2rCses-cDXjiZQ41wVXiMfssVmq8bVCEPuOpo5A&usqp=CAU"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">The Blue Book of Fairy
                                                        Tales</h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-80">
                                        <img src="https://images-na.ssl-images-amazon.com/images/I/511+MxS6IEL._AC_UL600_SR600,600_.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">Illustrated Fairy
                                                        Tales</h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://usborne.com/media/catalog/product/cache/29b1c625a6a034d41d27bd6a2f264776/9/7/9780746064115_cover_image.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">The Usborne Book of
                                                        Fairy Tales</h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://images.penguinrandomhouse.com/cover/9780385379144"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">Little Golden Book
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ2HCHJos6whOfZo0Urg22v-i4MEQVuUJtiIQ7qNgCs5s1zd1kvPDtoyJXHRWsGj9aC3ow&usqp=CAU"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">The Everything</h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                            </div><!--grid-->
                        </div>
                    </div>
                </div>
            </div>
            <div id="bca" role="tabpanel" class="tab-pane fade">
                <div class="alert alert-info">
                    <div class="row">
                        <div class="col-md-12">
                            <div id="grid" class="row">
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://m.media-amazon.com/images/I/716hbj45eOL.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">Discrete Mathematics
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://m.media-amazon.com/images/I/516dowgvA4L.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">Cyber Security
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://m.media-amazon.com/images/I/51WvmHSH3LL.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">Unix and Shell
                                                        Programming
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://m.media-amazon.com/images/I/81jV2IEVcVL.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">Relational Database
                                                        Management System
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://m.media-amazon.com/images/I/6161h-ZkhuL.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">Python Programming
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://m.media-amazon.com/images/I/51EWRgaqIKL.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">Java
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://m.media-amazon.com/images/I/71U2tTFifoL.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">Data Structure In C
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://m.media-amazon.com/images/I/71P-PE6A-bL.jpg"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">Internet Technology
                                                        and Applications
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                            </div><!--grid-->
                        </div>
                    </div>
                </div>
            </div>
            <div id="Sciencefiction" role="tabpanel" class="tab-pane fade">
                <div class="alert alert-info">
                    <div class="row">
                        <div class="col-md-12">
                            <div id="grid" class="row">
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxQUExYTFBQWFxYYGBkYGRkZGR4eHhkeGRgYHhgZGRkZHioiGRsnHBgZIzMjJystMDAwGSE2OzYvOiovMC0BCwsLDw4PHBERHC0nIScvLzEvLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vL//AABEIARQAtgMBIgACEQEDEQH/xAAbAAACAgMBAAAAAAAAAAAAAAAFBgMEAAIHAf/EAFEQAAIBAgMEBQMQCAMHAwUAAAECAwARBBIhBTFBUQYHEyJhMnGBFCMkNEJSU2JzkZKhsbPT8BczcoKywdHSFUOTJVRjdIPC4TXi8RYmRLTD/8QAGQEAAwEBAQAAAAAAAAAAAAAAAAECAwQF/8QAKhEAAgICAgICAQMEAwAAAAAAAAECEQMhEjEEQSJRYTKh8BNxsdEjgcH/2gAMAwEAAhEDEQA/AOcbc2xiBiZwMRMAJpQAJXAAEjAAANoLVTG2cT/vOI/1n/urXbx9k4n5eb7xqpIaaEEY9sYm+uIxH+s/91eybXxI/wDycR/rP/dVFRRXY+0zCkoyFlkAQGxADBlLEMN5ygra5GuoIpgVRtzEaeyZ+N7TSf3Vt/jeIsfZE+/4WTd9KmKXpcl4ysciMphy5cov2TXY595BUsvZ+SDYi1jVHBdIEyBXWQESu7iMZhiBIts0mZrl1ILDeu+wFMAa+2cR3vZE/wDqycv2q3XauJuPZE+o+Fk/uo3g+kmHjRVWF1EaIgayMZLSK6s+6xzZ7rdrhwLiwIAYvGKzyPdgM2gY3ZV9wpPEgcalt1pEkuJ2zOi+2JyeHr0n926psHj8TvbET3JFvXn/ALqHbOTtGLtuF7D0aUQh3+gCtMcKWyZy9BSXHzaD1RMD3v8ANfn+1W2K2jMLevzDVf8ANfiR8aqbJdgeWb066V7i27y6e915WO+tTI22jjp7ADETg2NiJXGt9L67qEDbWJOhxE4ZRY+vP8/lb6tY1735668N5obi4SR2g8ob/Ec/RuPhWc4+zWD+zf8AxrFC4OJxF+Hrz/3Vu228R3vZM+7T15/7qHmzj8+kU07N6UxpGgftFlQANLGieSrluyykgHPchn0vZAQQKzs0Ar7bxAI9k4jd8M/91aLt/E6eyZ9/wsn91GMF0hgjIzYVTYyG669n2kquirc5e4F0zC9wNwvU8nSiLJulbKCruyJ7LupAWc3OXLcW8o2GutjQAutt/E/7ziP9Z/7q2/xzFW9s4j/Wf+6mI9LIC+ZY5Ih2jvZFQmPNHkHZ3NrKffC/fOvNY2vjO1meUKEVj3VHuV4LppupASjbeK/3nEf6z/3VsduYr/eJ/wDVk/uobmrC1AHQOrba0smKZZJpWAgY2Mj2uHise8d9ifnrKo9VZvi3+Qf7yKsoAX9u+2sT8vN941U1FXduj2Tifl5vvGqoi30/N6EJm6+I0uLgGxIvqAeBtTxidr4dpWb1aSrrOkK5ZFhwqtDkhDxhLq4LMpMYbnxpEPjW0bfNQIcRtXBrC8d2YthjhxII7BFRSQxUgt67Oc1xqFC3tciruJ6U4aT9ViWwwSAQxNlkLJ65GJTGUFwGiiQqlwAWcEi5NIaPY24Gtey1vw32p0Ox9g6S4Pt48Q6NftJSI1TyTiHPaSPfusRCqiw91ISPJoZHtfDiH1PECzx4eSOGQLbM07N2we+uUKwKk7irDjStiSQAbEE3FxwHIeJq7hIhGtuJGv8ASqUbE5UiaEhFAHAVuAL3HG1QF+HGsjfS3LWtDJl1ZtT4BtfSayWUAgnUAC9UZpCVN9+p+evGPLflB+2nYUSynMDbjf7a0DWt4Vqs1yfCoS/Gix0VMTF2bXHkN9Xh5xRXovLGmIEkkix5Ulyu4YqJDGwizZASBmO8A1WyBlIO4n5jzqjHGcxQjvDdyI/+NRWUomkXocsLt2GGKPJOOxSBopMIocGeZ1ZXeTu5GjJIcOSSAoAUGt5trxtK6jGJ6mfDyJh0IkCYdmQKokjCWV8pcZ1DXOt9aSNOFbk1BQ1bV2xC2EkhSW+sCRhVKtIsKWkaYEW7Etd0Fy2Yi432Tytek61saANQLVoa3JrQigY49VXtt/kG+8irK96qT7Lf5BvvIqykAD26fZOJ+Xm+8aqSmiO21HqjEX+Hm+8ahrfVTQjeRr1oKZm6NZdmjFlgJmbtFjsc3YA9mZP2c9jSzQB6o1qd5ABm38hzNH+iEMCxYyaeBJzBFG6I5YLdpApvlIJ0NW4cNg8ariGD1Ji0UyJGsheKcAd5AHuY5bagVSYqFnDKwW7jUnMvMG2pPhU7NfzcD48j56NdHBhxhsZipsOs5h7ARpIzKB2jZWuVIJsDUWEEONxWHhjgTCxyMI3ETM9xqS/fuc1tBVJ1oloDyH5//itAdfRRjb+0cM+aLD4NIBHI1pC7tJIqZgVlzGwJ0bwtarz4PD4KOJsVB6oxM0YmWFnKxQRtcIZSuskjWJy8NPS+QcRcY90+atXbX90fzpow6YTHB4Y4FweLyM0fZuxhmyi5iZHuUci9iOVDNh4JJMNjpJFvJBh4ihNwUbtcrem1xrQ5BxAsh1PmtWq6kVswJNuQ/nrTDhejt9ntiiwEhYvFHxaGIhZZP2QzenLRddioBu1hc6AfX5q0BLByAA9sq+bivnopsvbGHQBJcDFOS+kjySKwDEADKjAacKK9NsRhMPNPhYcBEpTKqzdpJnUlVbNbNlJF+VKUt0UoiPGfn3Efzr1qZdvbLXJs8wpaSeAFra55GkyjNfgdBRHanqLZ7+pxhkxmITSaSZmESPYXijjQi+XcWJ31DKEcV6zU2Y/CYTFYeTE4SM4eeGzTYfMWR0vrLEW1GXivCtdl9EzicB6oiI7dXlAi91MiBWfIOLIGvYakXpAKZrUmmDoPgYp8SUlUOnYYh7Ekd5IXZTpyIBpeXdQMcuqj22/yDfeRVle9U/tyT5BvvIqykAD28LYnEHj281v9Rqj2Vs58TPFh4/LlcIPC51J8ALn0VJt8+ycR8vN961ebE2tLhpGlhYI5Ro8xAJVXFmKX8lre68/OmI6Fi8ds58cCuPIiWIYNYfU7FOzC5LdrntlL9/Naud4zZ7QTSQt5UblPPbcfSLGqqoD3fc8fGi+O2nJiJO2nKlkjVWZVC3VdEDW3ud1+QppCbCOxFy4TaQuL9hD9cy1Y6usCDiUxJ0w2EBlnlI0JCmyX4sxIAA4UL2Ht6fDdo0XZZprdoJI1cWGqqAw8fsrfa3STE4lVSWUdmpuIo0WOMHnkQAE+JvVUK0kE+i20ezwm0MQYonbPAQky50GeXW6G17A6Hhagm0NsGaRZgIYWTLl9Tr2aqVN1YAE9+53+Aqzsbb8+FEiwGMCTKXEkSSXy3y+WDbfW8/Sad5o52EBeMFVHqeMJZt+aMCzefhRTsLRd6SMMbgztExqk6SrBOyiyYgsLpIo4SC3etWdPUdpI8Ye9DiIYckg8kGNMjRk+5cW1B5mhW2+kE+JCLKyCOO/ZxRoscak72CJpm8TW+w+kWIw6OsMgyMQWikVXjY8zG4IDeI5a0JMG0WOgGzzLjI5CbQ4du1mkPkIia6tuudwHjVrZOJWSLbMosqyoHUcg+IJUfMRUG1ekE+JjEU08cUVw3YRxrGhPBmVB3teZO6oth7WbC9p2E8XrgUPniEgIW5Gjg21Jp8Ww5ICbOw74iRIE70kjrGo8WNrm3Ab/AEV0baOM2emNiHq8omHjGE7L1OxQqt1kvJnsQXLNmty5UtSdLcSZo5w0IkjEio8cKLlDizMAB5RtYNwuedKjWN/Tv3/PzpST9hFov7VwDYfEtAx/VygA81zDIwPIraifWUf9pYrzp9ylDNp7alnaJ5SrPEiRowUAlY/Iz2HfI5motr7SlxE0k8xBkkILFQANAFFgNBoBSKGzG40QtsaY2CpCjEngBMdT5t/ooJ0x2dLBjJknGksjSpINzCRiyurbmXva1Rx+05Z1hSQgrBH2UYCgWQG9jbyj4miWyOl+KhjGHDxyRDyI54llVDyTOCUB5bqVMC/0IwphjxePlFoY8PLCt90s0oyIie+te5I3WqumMeHZWFlico6Y2VlZd6kRR61R25t7EYxVaaS/ZnKIgoRI/wBiNQAD47+FUMRtSVsPHhiR2SSNKoyi+ZwASW3kWG6k0CZ0Lo1FHipW2jAqpIIMQuMiWwCO0EgE8a/Bud4HkseWtcqQ6Vd2XtOTDv2kTlWysh5MrgqysOIsfs5VSA0pDHPqq9tv8g33kVZWdVHtt/kG+8irKABG3FHqmfQfr5vvWqn2S8qt7aPsrEfLzfePUWFw5kbKvpJ3DxNNW9IiTo8wmHZ2VI0LMxyoo3sx3DzcTXQR0FwmDiV9q4rIz9/sI9WY+Yd4gbr6CpuqPBxRnE46QXTDxNkvyVczsPOQBfxrn21dpyYmZ8RMxaSQ5jfgPcqvJQLACqrdAuh09V9HCbdjjAPf2+vyr0m48xdtL2BYwZ27It5WT3Oa+t7c6qXrZDVJUJsx3sCeVMPSLo0+Gw2Fma15kJce9LElL8tNPRUHQzYpxeMhgt3c2d/2U1185tT7tHaq7U/xDCLa0JBw2gHdj7unMdohP79JumNLRykmj3QbZUWJxUcEwPZsGZspsbgi2o8CaAwjMdR578CN4t4U09V0ubacVtwVreOq3NU3SElbBO1cDFHicTGQ5CTyxoL+SqSFVud57oqskcQN8jfSq10ka2Nxf/NT/etQ8tXK8s70d8fHhxtjPhNgQHZEuNs3bpKqKbm2Vpghuu6+U2pMljsxFdDwunRvE/LR/frSC/fXNxHDmONdEHyjs4prjI0w0QaWNSO6zop52LAEfXvrpnSHo9sLByLDOcUHKLJZLsLNe2t9+hrmWzrdvDb4WP8AiFO/XOpOPSysbYaIGwJsbvppUsYM6TDZQjT/AA8zmXtO/wBqCBkyte1+ObLXvVzsGHGYvsJwxTKWGU2N7i2o4UsIjA6qw5XBF+dr76eupM/7S/c/7hT9C9l2XD9Hs7oZcUjAlGbKxAINrm19xG+qm3eri0BxWAnXFQa3AtmFt9rcfikA0m41yJ5La+vSX8xZgQfCmXoFt58LKrrrDJ61Ml/KUmytb36E7+Io42gtISco4VsEFM3WLskYfGNlFklUTLy7xIa3pBPppavUjG3qsW2Lf5BvvIqyveq322/yD/eRVlIYE2upOMntckzygDmTK1qJLhyg7BT3jrM4+qNTu05+LHlW20AIJsRiGNpHnmWLTyR2jZnI5kE28AeYqhjJii5BcZxmYe6UNuzH3zDUjgCBW8IqKt/xGUrbpDx0OxAlwePhjsbq0Ytus0dhYcrggeaubQ+SOfH+dH+hnSM4HECTIXidcksY3sm8Fb6Z1Oo9I404bb6AR42+L2VNHIr95oibFWO/TfG3MEVDe7KrVHM6kU6Uyp1cbULZfUpBOlywt89BotjzPiDg1UmbtTEQutiDZ2HxQLm9NNA0dE6rdgzjA4nEwKGxM6mKC5sFXcXJ4byfmqDol1d7UwuJim7OLIt0cdpvRtG4b+Poof1tYpEfD7NiNo8LGC4B3yuNN3FV/iNInqVbEm9rcz6B56lKwbSGLrB2V6mxksag5JSXGluNnUfvfUan6qFttGEfFb7VoxtSJ8fsuLFBWeXDkrK2/wAkZXLEc1ytQ/qugY7SispPcc93XS666cKzlJ8lE6MeP4OSAHSk+zMX/wA1P941Cc9P+3ernaUuInlSDuSTyyLdgDZ3JFxw0NKfSTo5iME6JiECNIpdQGB0Bsb23G9ZuLN1NNKmN2BP/wBt4g/8WP8A/YWueI2Vr+5J189dQ6NbFxGJ2BJDDGXeSUZeA7k+Zjc+agA6q9qN3ewXXiXHz1rFtNHM6ldinhltiISNxlS30xpXWesTp5icFiUhgSFlMEchMseZrsWB1uNNBXKdnKe3ijNywmjUW5iQCw8eFdQ6zOguOxeLWaCC6CCOO7MBqua+h141cuzJdCJ0l6X4jH9kJ1hURZivZJl8q176m+6jfUl/6kD8Q/xCg+2+g2NwcXb4iIJHmCXDgm7Xtpy0o31JqTtAkKWyxsxsOGYUeg9iPtJ7TS/KyfxmrHRyF5MRFCgJLyKPruT81Nc/VTtSSZyIUVWkZgWcWALE8NaP4HCYPYStLNImIx7KRHElrJfdmt5C33k6ngKXKuh0DOuh1OKSL4GCNMw4SMS5VvOpFc1F+NFsVtaSczPL3pJnLsTzvcgcrDReVrVQy5hcbxv8R7631U5LSoSf2NXVh7bf5B/vIqyverM+y2+Qf7yKsqCgft3vYjETSXypNKsS++YObD9kWufQKCtKTdmN2JuTzq/0mmL4mYHck0yqOXrjXPnJ1NDD7nlmH2irbJSJmlXTUbudbYbEMjZ45GRvfRuVPzqa7htzHbNwUUbz4FGDt2aiKNCbqgLFs5HPheh2z8LsPal44YjBPYkKF7OTdqUCkrJble/hQ5WFUcym6S41hlONxJHLtm+0GqcE7qc6u6Pr31Yhtd/eBvrx51f6U7Bkwc/YuwdSM0Ui7nXn4MOIqvsdQcRh1OoMqAg7iL6g01QnZWEoY3Zs7XJJLXZieZOpraaRT3Qy2vvv9I/0rtHSHa+zMGYxPgFJkz5BDGhsEIBLF2XU34ULPTXY3HZ0n+jD+JSc0lsqGOUnrZzyLEMFIjlkRDvVJGVSLW1Cmzaaa76rI7obo7xm1s0bFTbTQ5Te2g+arW08VFLPNJGjJG8jMi6AqpPdUqLgW8DVeOInVCGtvG4j0HQjzGsYcVrlf9zqmpduNP7W1/2iOXamJG/ET+B7Z7fxVTxGJkkILySSHcC7FiByGY6Cj/RXY7YrGQQWsGbO/IImrH7B6am6wNmrh8bJ2Z9alu6NzsbOo8bi/wC9VuG6sxWVVdbAeGxsyAIs8ygbkSRlUX36A2FenbGI4YnEeftn+rvVC0fmA8T9Z4k1q7KOZ82g/rTdLVijb3V/4IHBBDgkMCDe9je9wwO8G/Grsm18RYN6qxAB/wCM/wDM0d6E9DJtoMWBEUCmzykXJPvIx7pvsp+xCbC2UezdBLMBquXtZL/GvZIz4XppomV2ccm2pI9lknldd9nkZhfgbE2rMHjHQMYpHQ31ZGKkjkSp3eFdbfrWwAOX/DpLeKxfZ/5pJ6wdvYTFvC+EhMOVXEqlFUliwynuEhtAdaaf4JaAGJ21idzYnEEHSxmcj6zQ2Irc68Dx4019XkKPtCJZEWRMrkowuDZdxFdF290k2RhJexn2feTIrnsooylnFwBmYHTcdKT0xo4csg5/XVhJbESZd2jjnfiOVx9ddW/SFsPW2zpL2NvWId9tP8yuS4RshuQDpYjmP60Jgx56vMPlxZZT3Ggcqf8AqRXX0GsrXq6jZMUyg5onhaRL/txj0EbjWU2kTsVtuj2Tifl5vvGqmfc/tD7RVvb3tnEfLzfeNVZ7d39pftFSuimdU63/AGvh/l3+5WuYJiXiKyoxV42Dow3gg6EV2TrD6OYnFQQJh4s5WRpD3gAA0aqN/iDQvol1UyLIs+OMaxxnP2atfNbUdo5sFQcfNTTBrZF1q4HLg4Zn0YzpYDgJInZ1HIaA0k9G8IXxEJHuHVj4AEXNMHWr0nXGypFAc0MJYlxukdrBmUb8igZRz1qPZmHEJigt64zxPKeWt0iv8Ud5vFhVwi2myJy3oL9bA9cwh392f+NKQ5Deuy9KdlbOmMb4zEGAr2gjDPlzajOwAG69qDJ0a2GSP9oC1+E1v5VzThylcmdmLK4RqK2c1tXhQ637v1f+alEx5Bd+g5cNd50ryPCPKyRp5UjBE8STbTwHOnCMfS19sMk59OW/pf8ArOidVuETDYXFbTl8kIwS+l1Tl+25Aod0mUYzZ6YlVUOo7ayiwHuZ1UcACCbeAon1s4hMLgsNsyI2zWZwPeRaLf8Aak1/coF1a48FJsM2tj2qi+9WssoA5Cyn0mr5fIx4fGxKeMcx6f617hdnvLLHCl80jqg8Mx3+jfRXamzwsssHdSRG0XckynVTGdySZSO6dDrYjdU/QOPJtLDXvZXJIPAgHQg7jTlT3QRbSqzpPTva42ZgY8PhSEc3hiPFQqjtph8ckhQeBY1xlMGzC+pY3bXeTxHMk09daD9rNhrk6Qu3paVi38qUIxJGQQeduOg3m1ZttvTV/RcUlG2nT9lBVLpfW66X/PGq16IJ5V7EjUnn4/XrVXFx21G4/n/zW70c6auhi6tD/tGL9iT+E1P1r/8AqB/5eH+Cq/Vjb/Eob7sj3+ia6J0l2DsiabtMXijDMUT1tpLEKB3NAOK2NR7LOH1uK6Ztvo3sNMPM8ONDyrE7Rr2t8zgdwWtrrwrmKmgB06q5fZLqRcdkzDmLvFf0HT5qyo+q322/yD/eRVlHJioX+kB9k4n5eb7xqp38n9ofaKvbc9s4n5eb7xqolh3QPfD7RQuhs7R1gbdxGEgibDSmFpJWV2AUlgsSlR3gdxvu51zPa3SDF4gAYjESyr71msvpRbA+mnzrfQ+psNcEevvvFv8AKXnXOsHhWkdUTVmOnIcyfAb60hGzOcqCGxoBGj4lxdY/IHv5T5A8QujHzCrmzZH7WEObu0iGQ8yWBt/M+epNolBljXWOA2T48ltSeeW5J8SBwrXZsfr0J3+uKT9L7ajycnGoRN/Ewc7nL6Yx9aa3kw3mn/jWkTIBpYW4HmeAtxrrHTTopicWYTAEyp2gYsxU99gQALeFAo+rnHIO6sOcjyi+7wQW0/a3nwrPituW16RrGd8YwdOtt9CkMEQozrdr3C33A/CH/tFOPVbsky4tsSVUiBbJ73tHGmvABdfTQTG4JoHeCXL2kejKLkG4FrHidRTxPl2fsgqWEcs4K3OhDyjW3PLHf5xXPDLKcm2qSO/LghhxRjF25e/v8g7bm0tgYmXtcRK7y2CFgswFl0AUDS2+o9lYvo5BKssUrq66C6zW10IYHQrrreuYydnfRswGmgPCoJSLeS2umotWiyX6OWfjqKpSHfrO2fdkxOUDvGKQLqttTGR8W1xfxFANi7QCTRSyk+tsvrnELuKuPdLY794pw2D7P2f2VizhewawJIePWFz51tr4GuZpiGRrMtmUlWU+fvA+OhqnyTtGUeDjxkdI6ebLdY0nsSIXKSEa2STVH/ZvbXxpRwpvdz5R0UclHPlcm9OPQLp5CQMLirKoTso5JNUaPhDPyA9y/DcaJbX6rWBMuAlUI/e7KQ3X/pyrcEeelOHKLa7DHPhJKXSOemG4N95+y1t9Dlj1aJuVweJX3wHMf1p6/wDoLaO7sU8T2gIt57UD6V9G58M0aS5e2ZTLHl3WU2ZL8b76XjucfjPoPJjjl8oPZF1bRldpRA7wkn8J1FT9ay32g3/LxfwV71ed7HQOBvWQacO5qDx0P1U09NOr3G4vE+qIRDkMUaDO5BOVbE2y10NUzlT0cesK9FP6dTm0jp7H+mf7aRMREUdkO9WKm3NTY28LipKG3qt9tv8AIP8AeRVledVntt/kH+8irKAAG3T7KxPy833jVRB1uDYixB8RuNXtvD2ViPl5vvGqmkZJA/PjTSsGGtp7axGIVBPPLNbvL2jXCk7yOWlEtnBoEXKPX5wcp4RR28tvPYt5gKFYKAM1z+rTLcH3V9FTzk0fx0Pd7K4z2LSvvzX4A+9sAoHJfGuuMaVo5m7ewY8oJAQHKBZOZHFj8Zjcnz1e2dHIWVlbJlYEPycbinvmH1ViYYJbMP3eJBOmbio8N9T9scwN93LgOAUcBXn5ZrG2+5fsj0sOOWWktR/dh9tq4sC3qqfTXMZN/MknQfZQXEdL8UB63i5msTdi+VB5j7r0VS2nO88wgQD9kmwPjIRw8Ka8L0YijUMxWWX4RxZU0ucq7lUAb99cDm4/Kbbb9Hp/CPxjFV/YTu1xMz9tmlkkJDdp5K5ltZsx1Yiwqptbbs8tu3xRmKXKhu/kzWzWLC2bQVZ290lL+twaKN8nFv2Per9dBMBsmacMYomex7z8FueJPjXRjTpuWv57OfNki2lDb/nRtLj4iLeut5yo4DcBu1v9VD2m/wDAvu+ere1dmmFxGzo7WuchuFvwvxNUClbRUatHNKcrqQQ2Xt/E4fN6nnkiz2zZGIzWva/zmqWLxTyu0kjFnclmY72J3k+NRZa9tVGVHubS1qM7C6S4jCgiGaVNbjI5yj/pm6m/iKCV6KBo6GnT3aE49Yxcivxhyx3PMwtku4+J5XK9K20to4id+1mnklcbmY3K67gD5OvAUMSFrBxe28EcLcfCjMGNjn0lKxzbhMdEk5CcDyW/4g9I41acWqZDUovkujNmY+SKUTQyPEzgqWTQo9u8RyDbz4Xq1J0t2iGKtjcRcGx79UHV4JSrqVOmdW5HcwI0YW3EaEV7tGAaMNbDfxI4HxI3ea1bxjcdnPKSUtdEz9NtpA+3sRp8c0vO5JLEkkkkk7ySbkn01Pik3H0VXIrKSpmi2hx6q/bb/IN95FWVnVX7bf5BvvIqypAAdID7JxHP1RN941Zs7DknKB3ybAHQDjqeXEnwqztPDXxOJY7hPNbziRq2cZUsP1kosBxCHw4s5Fre9HjW+OPtmcpegrs+ePMI0UyBAxQgauxsCx4662JtZb1G+PClgB2jk3LjyFPEp78jcG3C2nOoY4SqGNSAVsXYC/eOh/dHkj01pHBJpaUafFt6Lis8+aUfitG/jePGXylvZtHjmBNo84OtySS3n5tU52o4F+yIIFwdQPMTb6q8jw0xPdcj+vPdVhMNiQO5NZt977/HUfOK8+4vs9Omloo7DxOaZi7MpfUKgHfYtojFty68aZNqTYswSXcCMrZgclwF3hrjVT4amhGD2HLnuSh4tytfeDbQ3pq2FjZADHNF2oBsFcANY3BAJ7s4PLf41nka5JoatRpiFhtjyHMuRyVscoBJG73oOljv0FGsFBkTyUDEbpHUAELoTFIoy3OW+h0Bsdb02DZEYCyYaR0AvkjZjHNFvI7Nie/HmI0PLed1MmAXFCwZBMwKht0chtqbb0ZTcanLvpvJy0Raj0cg6SQSNO3aAAgKqgBbZAPW7GMBTpxFBmwldY6d4RcRLHiI1dTkMUquuUgoxym4urb2UkHhSnitlld4rWMqRPHkroTnwtQtFTHiMFah8uF1q+Yv6f4BBSvMlXZYbcKgK1SZnOFHsUpAsNPH+vA1qwO8/n0VKymwFq0tTQmmEMFtIZBDOpkiHkEfrIeZiJ3rzjbunwOtSzwNFZwRLEfIkUd1lG8MDrGwvqpsftoVlopsiSyziwPrWbw7rqCLcbqxFbY8jtJnPlxLi5FLEIpU5b2O4HgRwPj/AFoeaIiysVuchO87x71j89j5zVfFQEXNvPWuSN7OeDrQz9Vftt/kG+8irKzqr9tv8g33kVZWJoQbQjBxGILeSksrNbjeVgqDxY6eYE8KiwsTtmmAu97IAONtSv7K6Ac/NVvbhs7KNzYnEOx5sJWVV9AN/wB6rUceTuqLi2W2uu438CWufTWmXJwiuPYePhWST5PRS2KUBaNiAXtlY7jlvpfncjfyonPhyOF/RvvxvVXaWAv30Xvbj8cfGO4SD33EDXXWptmbQACpNqp48Ry9I5Vy5YvIuce/aO3FNYf+OfXpm2DlI9P5386JIoc3Vi3xftA8anm2T3Tl1GhRgfH7KnweC9B36cTXC2mzvWkU4nymwOUnUrvJH9P500bLtIgRirxEnRret2B0I99ewBGtAGLaKy7tR3bkHUgeLCx0FHtixf5l75h5LbmtYkgHedL+FuNUoWRN6Lc+Eit2a5o/ehx2ljbWMK17Cx3qCAOINEtm4FVhVQ2moF3ZS2uhXNpe4sDQ+HGK4DBi2TNa4Gdcy2Ns3EniRbXlVuPaSqptCHJBsCx0JFtL6ILE+TzOmpq1BHNLk9BQ7IkMTKVlcsBcyGNjp7kMLEm9+/8AbSrtDYD94Ara3HQi3DWmzY+0Xy5JSChGmUWCDkWJuSOfG1W0wMLtmuSirqvPfbxGgrTimtGcZyxvZxjaGzSCRxFBMRARvruU/ROGYFo5GAuRZhe1uR0Pz3pdxPQK3ekkAUbwFN762sb8vr0rJxmmduPycbW9M5HLCLbqpnDa7qeOkux4IQUhLvIpIkkcjQg6qEAAXhv50r4giwP5+enGbWjtjgjljyBkkNaGMCrspvUJWtYS0YZcEYvRXAqfCPlLaXzIyH07j6CBW0cN/Ac6ilcDQC/h/MmurHHXJ9HlZ5K3jjtv9izhNnmY5QyqxB7MHfKQL5F97e2hNgTpVaPVfFbA34i9gT4g6HzitYs+8Eg6EHiCNxHK1FpgGxUThbjEquZRpYyXSW3iGBceNq2hk5t6OXLg4JOy71aR2xjkagwPpy9cirK96tW9lvfd2DWt+3FWUnBEpnu1o82IiS/lYjEk+btz/JaJps2LeQbHdZjp59d9U9qoTinyWzRrKV5B2mNgfPfd4iimyMror6BWBzfFI8sfVpWWdySTizo8SMW5RkjXC7AR2sFNtT5TajmBffXk3RdXUohytrlYklTb3Mm/Kp98Nx8KaMDhMpvY3sB3uZ3k8iLVc9SDeBxHDffjpzFc0ck1K7OiePG1VIU+iu1GQthsSjZUuLtvhPvHA8uMg6HXgdRTUuzwN4uNGU8xe4I8BWu1tjrOo7xR1Fo5APJ42kHuozut7m9xyoFs/a0uGkbDzIcqEHKd6X/zIyPLjI1sPq1FbywRzLlHv2jmjllifGXXpjC8Aa7KLEag2sBbnca3rWDZalChzEfGJ1vvsd9vTRAMNGBzBu8CNzDncV4NDzHCudY6VHS8jKGHwFt+/gfz9lXEgCWYnX886mZL7tK0Yi2up43/AJVSjQObZrFI5f1sA/GOgHO199NGy5CqDNrrpbcT/M8aA7NwxLHXQ7hy5/ZVrpBtsYXDSTmNpFiUHIu85mspJHkrfeapIibVDHKxCkxqM1gcp3Hw89Ju0+kLqGGU5vKMjGyrqbLysDz50y7Ix/bQQz5SvbRRy5b3Kh1DBb8d++q21sHHKLtGut81xv8AekjjqKzyxbWgwOKlclZxPauOkld5GN85uSfq18B9tBJyDpXU8T0KR2ZzLkQm5va4tyA0tQPp50Zghw0UsRGe4GYvbtVIJOUbiRyHCuaEWj3o+Zj1GIhaVnZcW0HOrGEg0zte3uRxPI+bw41riZhfmfqHh4mu7HiUFzn16X2ef5XlSyS/pYdv2/SK0wuLbuQ/m39KqHDgVcNQsKU8zk7MIeNGCpq39kAhH5NXbqi4SVRYrOyueZV42W/mVqgAqHaMx7LKNwcODxvazejd9GtcEpW9+jDyowUUkt2NHQOMLtLEKPcrMvzTR1lW+iAH+K4gi1miZxbcQ7QsCPnrytZdnFZHJKI9pyyMmZczsUFu8pAuuvp+ainR/EwjFTQRXEMxWWHN3cji2ePXjy8woHtLXGLxzSyIfG00ikA8DbSij7EEt/UzFlubRy2DDKRcZxxB58ONOShxqWr0PG8l3FXWx7hJvlYbgdTu3G/zfzqeOMW5mw1OhtwB+ekGHamLwpUSFgm4JNqjX4LKNb8tT5qZtm9KsPIQHJgb4+qHzSDQfvWrGWBra2vwbryIy09P8h4RkqOB46899jxPKqm09mRzqFkupW/Zyr5URPh7pL709IopDh2YAqMwOoK6g+YjfUUsZG+4qYtxdoqUVJUxRXHNhJOweM5PKaxuHB/zoW3EHivoOtNMTK6q6NmQjQjj/Q+FBttR+qZo8EGyrH7InkABaK4IjRL6B2JuRyFCYGn2fKY2GeN7seCTr8JGT5Eo3FfQeBrplBZVfUv8nLGbxOnuI7wrWmIiJNrVPsmVJYllja6k8dCD71h7lhyq4lvC/EmuVxp0zrU7WjXBJoToLj8/VXPusvHqMXh0nWQ4UpdgGsksgJORkBF1Fo7k62vaugxOL1yLruxWXFQIdVGGuByLyyAn05B81XHszyfpGjqu292k02GQ+s9k06JraNhIqssZPuCHvl3AjTfTxjm3WrmvUNg0ZMRiCDnS0Cm+mR7O2nFrqutdGxYP53ab7nhUzQ8T0DZ4EY2110Og/n6aVem3SRCDhoSHj0RiBmzsDqkI4twLDlYVD0m6TdoRBhszBzkunlTnisXKPm/EA2sKjw+yXwPZYyTK+Q5ZkAuII3sFeP4yHyjyNaQwrH85d+l/sU8spvjHr2/9AzaPRaeOHtpWjVitzHmGaMcFI5kb7UpPERbhXYtv7NEy3UAvbcdzqeX2g1z7GbIMeZCjXBJDf9p/rXHkyznO2er4sIRhxQuWrQrV6TDa6V4Yh6a0x4Zz3WiM+fFi1dv6WwdLe2m86VrjwBA4454wDbwe9vTVxl4XqntJB3EF+9ckX36gDTnvrphGEfinbPOzPJO5uNR132NPQlQMfKoFssJT6BhX+VZUPV6b4o/IP95FWVuzkRQ6RSWcMPKGLxOX92VDr+8aaB0qwkLyXlOdSRYKd4vmW+699L0i7dlvPOrMQFxExUZffSd7Uc8o+apoukkyiyrERv70CN59WF6ycFNKzSGSWNvj7HnZHWHBNKkPqd/XDlAYqVGbfcHQjwoztDovhpNY5BA3JSGjv4xk6DzEeauZxdMMQpuiwKRuIw0dx5tNKin6W4ljdpE439YiAN948jfypqPH9LoUpcv1Kz3pbgZMJiDEJAGCh7wyErdibEWtlPMV0PYvS1MNCYezeRkW6sZC/aMF0vn8gE+9uK5ZiV7Rix3m19LXt5hbhRGPHSCwDCwsLZRw8SKtKLvkiHKS/Sdg6JIiwkrKk0sp7XEOpvd29yRvVV3AGi2Lw8U0ZimXMhN9NCrcHQ8GH17q49gukE8P6qVk8RHGT9Ix3q6Om+M/3mT6EX4dZyi+XJMpZVx4yQ0TxT7PlVwwZX3PuSdeKyD3EgHHh5qb9nbTjxCCSO41syt5SH3rAbxyI0NcdxfSrFSrllnZ1vexVbA+Nl32qXZ3SnEQm8U2W4sbImo5Eld1aTakrf6vsiE3F0ujs7NYniP60ldbmzkaCKawEpvHn4lPgyDpbvE0tv04xbDvYlhfgFjH/wDK9UNpbWbEgDESmUL5IdgApO8gLHvPOsowp2y55eSqh66mZkXZ+Ild1BM5aRiQAoESWvbQaXof0n6TNiWGHw6OyMbKm5pyPdSH3EI5cePKkiDaskaNDC6rEzBmQKpVmXyWa63JGnzV7h9u4mJs8U5R7WzBV3HgbqRarioxfL36FKcmlH17OndHtgphhnZhJiGFnk4KPg4verwvvNE8QyZWD5ezKlXDEAFSLMDfwNcpTpptD/efnjj/AA6gxXSzGPpJKjgagNDEbeOqVnKLnK5M1jmjGNRQzYHpEMPE+H1xCxsVglVrZoz5N23gqDa45Ug7YRjizEryOgcKnfPknvWzHfbMdTW0uPkvfNcXNxYAa8rDSx105VRkUsSzEnz7yBu+qtHGNa7M/wCpJvYySoR708LBgT6arY+yRiVtVzZbixsbXFxf66XsRN3iAFHGwFrfNrWucaaHx0/lWUscpPctfXR1Q8iMI1CKT+3thX1SgOpy3GYFtxB3bq9xUdsRFY3vAZFPPuOfm0oTHicp8knzr/Kt3x7FlclwVXKLKNF17vmsTVQxxg7RGXyZ5I8ZdDX1bEHFG3wD/wAcVe1F1YNfFvvuIHBuLf5kVeVo8mzBR0A9t39VYi1v183P4VqqnN8X5zVnbQ9k4j5ebj/xGqBQnFgPOamL0JrZpnYX3fPXhYkW0PE+b01tJLEPdA+YGjOytkrLhp5wxvH+qTQdr2YD4jx7kRVvOaOQUBu0PKpEmPL8/PV/AjCyCZ2ilEcMSyWWQB3LSxx+UVKqBnJsBrYVcHRpPV8eGMknYyZGDWAkVZIu0VXFrCQaAi320WHEENjjusPSP/dWoxpOlr/nz1dx2xhHHGrMfVDWeRR5EKkd2JuJmNwSL90WBF63wfR7Nhp589nS5iQf5ixBTiW/cEiEWPBuVKw4g/tzy/Pz1gxNuf59NWtjYCN1nklDssMaMFRwhYySqnecq1gAxO7hV3EbEiyR4iNpmg7QRzRsV7aMgZrKyjK4ZLlWsNVIIoCkCHxJ5fn568GKPI/n96jj9F8hxBeTMkYUQOugmebvQEaG6GK8rW3BbcaHLsaTiw89j9m+mhUUvVXh+fnr0Ynz/n96juN6HukOHnEikTRlmHvXBJyeF48rC+u+q+2ei0kGHw8xOZpu0LKP8sLkMYPJmRw2vBlpDoGdv5/m/wDdWGUngfz6aJbM6OmXCvPntIrdyP38SMizSX+I0iegPyqbCbCiSOaWftGWLsQqxOqse0chj3la5AGg4k0WHEBknx+evQfCiWN2fFBi5cNMJJlSRY1ZHEZGYjVwVbvWaxXgQa32pHhYsQ2FjilukxiMjyhiwzBbhQihTvPGmpBxA8a2a9vz/Ot3mPCw896YcFsmGTEYnD9qYzD2oRn3FkmWOISEaBWLAFuBN91UW2eAmJMgZJMP2QKHSzPJkcNfkN1qpSXpg0weZOX21E6uT5YHhrReaHDR4eB3WVpZ0lYMsoVEKyvGoyZTmFlBOo30LFud/MRRyv2KqGfq2B9VtdrnsH3X+Ei386ys6t/bbb/1D/eRVlSylYr7dC+q8TmF/X5vvGqkVXgv11d2+PZWI+Xm+8aqyipQM0WPXRRTkvSZMM0CQpBLHhlXvkNmkaXvYjIcwABzMguDogpSJ00prPSTDFh6w6rreyRNvYsyhWOXI9wpAsVCgAmhjRU2LtKPBYjFvBKjhVAgJFxKvbxNkII3mMG/Ig2q9gsZAm0IJxOeyMnbFpGJeFiHukpOpZXtZhfMMpqh/i2GylRh2UM7ObBDbMjjIN10RmUrfXu8DXuB6QIkSJJGXKLlvljOcZnJjbOCQjBlBYd7ueahAyLa20o5YxiAVTEE5cRGdMzkX9UR8LP7teDG4FjRJek8eHlgjjjhmgw6iMyZWLyiS5xRQlgBmLyAXG4LQzA7djVYhLAJuzUC5tw7S5Hvj308q/keapMNteANIXgziR5WDm2dFkyWABJUlcrb+YsRrTGS7MhhT1bh1xEOVlRYZJGKpIseIVr3ANiUHEb71LisVHHD6njkWZmlEssqghO6hWOKIsAzgZnZnsPKAG69ept/DgKFhdMoCgqsRy2teazDvzOAFIOihmsa1wm2cOiv7DRnZ3cZiMoDG6RWtfs0Ko2m85xoDQmJkuL2xmw+Ej7S5iE4K38i8t4wefrY05DSqrYjS99SL/k0Wg29hlJIwdrlde4TYSCQaEC7DVB8XLytUMG2Iw0hOGV82UqWygghTmcgDKrs4jYhQAMrDXMadkhJNpws/ZStnwxgwwJTeJcPEpJQEe6btYmPKQnhVDae1GmgYkp27YppCgO5JIUW4PvVMaoPACpztnDkknCrqVO9RuMZB0Fle6tqNGDWI33h2rtOF8l4mASUyN5KtIpH6q+9VBAGl9CdBYUgNH6QxQ4iKNI4pMLCow/alWzvE4K4iRTmsMxeRh3eIqDYHSUYP1UVkSUhokT/AI6JJJmKta6HIQwbepsfCol2xhVd3bCZg0rSAd31tWUjs1W1iqk3A3A2PCoB0hwtyWwxzm47WyFgcxZWVGuoYFsut+6qctUykDNpiJMQDFN2sRZJQ7eWAzBisv8AxF1DW0J1G+tdr4tGx8kquDGcQXDa2K9pfNuva1Ecf0lieMomGRWKkZiFvcsM8gIXusyZlsNAWuLHd7Pt3DHPeBtf1bWjvCAGCxogGUrdiSx1NlvUsZE+0Iu32k+cZZknER175bERsoGnFQTryqebb0c2CmSQ+yssMYa366ONwVzn4VALZvdLbitexdIcMtssLAAMbZY7EnIArXuMuRCpNr94231Fhtt4ZUjR8L2mREGtrBgWzsB7sNnJsbapHy1dAWvVrNs+CKLGxxqkUyzQNKylyZpGtlCkNmUrbWlAoN4FN8XSvD6lsKAxN8yqhsFBEQ1AJIupLXB7niaUbned5uT5zTQDf1Ve23+Qb7yKsrOqr22/yDfeRVlIY1bU6vsM00jmScFndjZktcub27m6of0c4b4XEfST8OvKykI9/RzhvhcR9JPw63HVxhvhcR9KP8OsrKANB1e4f4XEfST8Ovf0bYb4XEfST8OvKymMxernDfC4j6Sfh17+j3D/AAuI+kn4dZWUCZn6O8P8LiPpJ+HWy9X8Hws/zx/h1lZTESDoDB8NiPpJ+HW6dCYbfrp/nj/DrKymSbjoHD8NiPpJ+HUEnQOH4af54/w6ysoYELdXuH+FxH0k/DrP0bYb4XEfST8OvKypKPP0a4X4XEfST8Os/RrhvhcR9JPw6yspDM/RthvhcR9JPw6z9G2G+FxH0k/Dr2spjPP0bYb4XEfST8Os/RrhfhcR9JPw69rKADPRToXBhp2aN5STGy94qdMy8kGvdFZWVlQM/9k="
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">A Desolation Called
                                                        Peace
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRygI1q2V_hEqWvo4DxGF2GZ4iUpEOt54fFBFGKmYipy3Fdk5N7hapquVdaGOc3OfKxCBg&usqp=CAU"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">The Last Watch
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTS6avHFtBp8xYKM3wQ3HU5mjSbFJnU7NfYEedXU4VlcDkDRNyWRijAmWBi5_eyJFBT51I&usqp=CAU"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">The Last Astronaut
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQsvRES32K8t1c6oLwL5DlgXUJYxYCE3MK6n1_0tdEUJHsMOPKsr3dgAPlfYw_-1Wagc-c&usqp=CAU"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">How High We Go In The
                                                        Dark
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2Ox9gTcONwmBuP1-r5xoqk0i3oC1PORjq4WtFZ_E97ECmDsqRbzN0PdstzpizFc3ydOg&usqp=CAU"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">Broken Stars
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSV-e7yzHtTERfBWE5OltiMngLruwDo-KRjKRle6qe6Voya4KhsD32l_Bj5rOj8udpWA5o&usqp=CAU"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">To Be Taught If
                                                        Fortunate
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://miblart.com/wp-content/uploads/2021/03/img_6054a6b8b5765.png"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">Heir To The Gift
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                                <div class="mix col-sm-3 page1 page4 margin30">
                                    <div class="item-img-wrap h-75">
                                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2qfs9FrtkjsdhgZ-g_e8VoqQURJ4DXbePHiQ5D308Z-WGFNzDLJuWSHg6GrTCN7YbNqs&usqp=CAU"
                                            class="img-responsive" alt="workimg">
                                        <div class="item-img-overlay">

                                            <a href="#" class="show-image">
                                                <span>
                                                    <h4 class="text-light chenge-font py-5 mt-5 ">Relic
                                                    </h4>
                                                </span>
                                            </a>
                                        </div>
                                    </div>
                                    <a href="bookinfo.php" class="btn btn-default w-100 py-2 mt-2"><i
                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                </div>
                            </div><!--grid-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <footer class="bg-dark pt-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-6 col-12 text-light">
                    <h5>EasyTutorial</h5>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mattis mi suscipit bibendum sit amet,
                        consectetur.</p>
                </div>
                <div class="col-lg-3 col-sm-6 col-12 text-light">
                    <h5>Quick Link</h5>
                    <ul class="list-unstyled">
                        <li class="">Courses</li>
                        <li class="">About Us</li>
                        <li class="">Terms & Conditions</li>
                    </ul>
                </div>
                <div class="col-lg-3 col-sm-6 col-12 text-light">
                    <h5>Help Center</h5>
                    <ul class="list-unstyled">
                        <li class="">Support</li>
                        <li class="">Get Help</li>
                        <li class="">Privacy Policy</li>
                    </ul>
                </div>
                <div class="col-lg-3 col-sm-6 col-12 text-light">
                    <h5>Contact Info</h5>
                    <ul class="list-unstyled">
                        <li class="">Call Us: +91-8906634065</li>
                        <li class="">Address: 105/5b, Dumdum road, Kolkata-74</li>
                        <li class="">Mail Us: support@softmaker.co.in</li>
                    </ul>
                </div>
                <hr>
                <p class="text-light text-center">EasyLibrary &copy; 2023</p>
            </div>
        </div>
    </footer>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.2/js/bootstrap.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="assets/js/common.js"></script>
</body>

</html>