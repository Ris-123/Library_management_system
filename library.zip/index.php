<?php
 session_start();
 include('db.php');
 if(!isset($_SESSION['usr'])){
    $profile = '';
    $registration = '<button class="btn btn-default ms-lg-3" type="button" onclick="registr()"><i class="fa fa-user"></i>
    Register Now</button>';
 }
 else{
    $profile = '<li class="nav-item active">
    <a class="nav-link" href="profile.php"><i class="fa fa-user"></i> My Profile</a>
</li>';
    $registration = '<a href="logout.php" class="btn btn-default ms-lg-3" type="button"><i class="fa fa-signout"></i>
    Log Out</a>';
 }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">

    <title>E-DAMY</title>
    <link href="owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="owl-carousel/owl.theme.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/Home.css">
    <link rel="stylesheet" href="assets/css/main.css">
</head>

<body>
    <section class="top-header-area">
        <nav class="navbar navbar-expand-sm bg-light navbar-light sticky-top">
            <div class="container-fluid">
                <a class="navbar-brand" href="#">Easy Library</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapsibleNavbar">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="collapsibleNavbar">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php"><i class="fa fa-home"></i> Home</a>
                        </li>
                        <?php echo $profile; ?>
                        <li class="nav-item active">
                            <a class="nav-link" href="contact_us.php"><i class="fa fa-phone"></i> Contact Us</a>
                        </li>
                    </ul>
                    <?php echo $registration; ?>
                </div>
            </div>
        </nav>

        <div class="banner-area bg-1">
            <div class="container-fluid">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="banner-img">
                            <img src="https://edmy-react.hibootstrap.com/images/banner/banner-img-1.png" alt="banner"
                                class="d-block w-100" style="transform: bone;">
                        </div>

                    </div>
                    <div class="col-lg-6">
                        <div class="banner-content" style="padding: 90px; color: aliceblue;">
                            <h1>
                                <span class="word-wrapper">
                                    <span style="overflow:hidden;display:inline-block"><span
                                            style="display: inline-block; transform: translateY(0%) translateZ(0%);">Improve</span></span>
                                    <span style="overflow:hidden;display:inline-block"><span
                                            style="display: inline-block; transform: translateY(0%) translateZ(0px);">&nbsp</span></span>
                                    <span class="word-rapper">
                                        <span style="overflow:hidden;display:inline-block"><span
                                                style="display: inline-block; transform: translateY(0%) translateZ(0px);">Your</span></span>
                                        <span style="overflow:hidden;display:inline-block"><span
                                                style="display: inline-block; transform: translateY(0%) translateZ(0px);">&nbsp</span></span>
                                        <span class="word-rapper">
                                            <span style="overflow:hidden;display:inline-block"><span
                                                    style="display: inline-block; transform: translateY(0%) translateZ(0px);">Online</span></span>
                                            <span style="overflow:hidden;display:inline-block"><span
                                                    style="display: inline-block; transform: translateY(0%) translateZ(0px);">&nbsp</span></span>
                                            <span class="word-rapper">
                                                <span style="overflow:hidden;display:inline-block"><span
                                                        style="display: inline-block; transform: translateY(0%) translateZ(0px);">&nbsp</span></span>
                                                <span style="overflow:hidden;display:inline-block"><span
                                                        style="display: inline-block; transform: translateY(0%) translateZ(0px);">Learning</span></span>
                                                <span class="word-rapper">
                                                    <span style="overflow:hidden;display:inline-block"><span
                                                            style="display: inline-block; transform: translateY(0%) translateZ(0px);">&nbsp</span></span>
                                                    <span style="overflow:hidden;display:inline-block"><span
                                                            style="display: inline-block; transform: translateY(0%) translateZ(0px);">Experience</span></span>
                                                    <span class="word-rapper">
                                                        <span style="overflow:hidden;display:inline-block"><span
                                                                style="display: inline-block; transform: translateY(0%) translateZ(0px);">&nbsp</span></span>
                                                        <span style="overflow:hidden;display:inline-block"><span
                                                                style="display: inline-block; transform: translateY(0%) translateZ(0px);">Better</span></span>
                                                        <span class="word-rapper">
                                                            <span style="overflow:hidden;display:inline-block"><span
                                                                    style="display: inline-block; transform: translateY(0%) translateZ(0px);">&nbsp</span></span>
                                                            <span style="overflow:hidden;display:inline-block"><span
                                                                    style="display: inline-block; transform: translateY(0%) translateZ(0px);">Instantly</span></span>

                                                        </span>
                                                    </span>
                                                </span>

                                            </span>
                                        </span>
                                    </span>
                                </span>
                            </h1>
                            <div class="text-warning">
                                <p style="opacity: 1; transform: none;">
                                    We have
                                    <span>40k</span>
                                    Book Choices &
                                    <!-- -->
                                    <span>500K+</span>
                                    Online registered people.
                                </p>
                                <form class="search-form d-flex">
                                    <input type="text" class="form-control" placeholder="search cources"
                                        style="color: #f4f0e1;" name="search" value>
                                    <button type="submit" class="default-btn">

                                        <span>search Now</span>
                                        <i class="ri-search-line">

                                        </i>
                                    </button>
                                </form>
                                <ul class="clint-list" style="padding: inherit; display: flex;">

                                    <li style="display: flex;">
                                        <img src="https://edmy-react.hibootstrap.com/images/banner/client-1.jpg"
                                            alt="banner" class="client"
                                            style=" margin-left: -20px; width: 50px;border-radius: 30px;">
                                        <img src="https://edmy-react.hibootstrap.com/images/banner/client-2.jpg"
                                            alt="banner" class="client"
                                            style=" margin-left: -20px;width:50px;border-radius: 30px;">
                                        <img src="https://edmy-react.hibootstrap.com/images/banner/client-3.jpg"
                                            alt="banner" class="client"
                                            style=" margin-left: -20px;width:50px;border-radius: 30px;">
                                    </li>
                                    <li>
                                        <p style="margin-inline: 10px;">
                                            500k+ people already trusted us.
                                            <a href="#" class="read-more" style="text-decoration: none;">
                                                View Courses
                                                <i class="ri-arrow-right-line"></i>
                                            </a>
                                        </p>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <img src="https://edmy-react.hibootstrap.com/images/banner/shape-1.svg" alt="course"
                        class="shape shape-1">
                    <img src="https://edmy-react.hibootstrap.com/images/banner/shape-3.svg" alt="course"
                        class="shape shape-2">
                    <img src="https://edmy-react.hibootstrap.com/images/banner/shape-2.svg" alt="course"
                        class="shape shape-3">
                </div>
            </div>
        </div>


        <section class="feature-courses-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 text-center mt-5 mb-3">
                        <span class="text-sm text-theme">Featured Books</span>
                        <h2>Expand Your Interest For reading books</h2>
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-4 col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="courses-main-img ms-4">
                                    <img src="https://merryrianashop.com/milliondollardream/img/MDD-BUKU-UTAMA.png"
                                        alt="Image" class="img-fluid rounded">
                                </div>
                                <div class="courses-content mt-2">
                                    <h6 class="text-center m-0">Merry Riana</h6>
                                    <small class="text-sm">By Easy Library</small>
                                    <button class="btn btn-default w-100 mt-3" data-bs-toggle="modal"
                                        data-bs-target="#staticBackdrop"><i class="fa fa-eye"></i> Read</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-4 col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="courses-main-img ms-5">
                                    <img src="https://histriabooks.com/wp-content/uploads/2020/02/The-Lost-Diary.jpg"
                                        alt="Image" class="img-fluid rounded">
                                </div>
                                <div class="courses-content mt-2">
                                    <h6 class="text-center m-0">The Lost Diary</h6>
                                    <small class="text-sm">By Easy Library</small>
                                    <button class="btn btn-default w-100 mt-3" data-bs-toggle="modal"
                                        data-bs-target="#staticBackdrop1"><i class="fa fa-eye"></i> Read</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-4 col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="courses-main-img ms-4">
                                    <img src="https://n4.sdlcdn.com/imgs/b/m/9/Mein-Kempf-Adolf-Hitler-Paperback-SDL298110638-1-fff4f.jpg"
                                        alt="Image" class="img-fluid rounded">
                                </div>
                                <div class="courses-content mt-2">
                                    <h6 class="text-center m-0">Photosynthesis in 3D Animation</h6>
                                    <small class="text-sm">By EasyTutor</small>
                                    <button class="btn btn-default w-100 mt-3" data-bs-toggle="modal"
                                        data-bs-target="#staticBackdrop2"><i class="fa fa-eye"></i> Read</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-4 col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="courses-main-img ms-5">
                                    <img src="https://m.media-amazon.com/images/W/IMAGERENDERING_521856-T1/images/I/51rmSgxnGLL._SX322_BO1,204,203,200_.jpg"
                                        alt="Image" class="img-fluid rounded">
                                </div>
                                <div class="courses-content mt-2">
                                    <h6 class="text-center m-0">Photosynthesis in 3D Animation</h6>
                                    <small class="text-sm">By EasyTutor</small>
                                    <button class="btn btn-default w-100 mt-3" data-bs-toggle="modal"
                                        data-bs-target="#staticBackdrop3"><i class="fa fa-eye"></i> Read</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- modal 1 -->
        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg ">
                <div class="modal-content">

                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title fw-bold text-light text-center">Merry Riana </h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <!-- Modal body -->
                    <div class="modal-body">
                        <div class="container">
                            <div class="col-lg-12 col-12 justify-content-center">
                                <div class="row">
                                    <form class="w-100">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <img src="https://merryrianashop.com/milliondollardream/img/MDD-BUKU-UTAMA.png"
                                                    alt="" class="src">
                                            </div>
                                            <div class="col-md-6">
                                                <h1 class="mt-5"> Merry Riana </h1>
                                                
                                                <div class="has-validation-1">
                                                    <h6>Million Dollar Dream tells the classic story of girl meets world
                                                        with the
                                                        conventional rags-to-richess approach. But there’s nothing
                                                        conventional about the
                                                        way Merry Riana approaches life and conquers her own fears and
                                                        doubts to achieve
                                                        great success at the young age of 26. The book chronicles Merry
                                                        Riana’s life as a
                                                        young child, a teenager, and a young woman who must learn to be
                                                        independent and
                                                        resourceful.</h6>
                                                        <div class="col-md-6 py-3">
                                                            <a href="bookinfo.php" class="btn btn-default w-100 py-2"><i
                                                                class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                                            
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- modal 2 -->
        <div class="modal fade" id="staticBackdrop1" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg ">
                <div class="modal-content">

                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title fw-bold text-light text-center">The Lost Diary </h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <!-- Modal body -->
                    <div class="modal-body">
                        <div class="container">
                            <div class="col-lg-12 col-12 justify-content-center">
                                <div class="row">
                                    <form class="w-100">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <img src="https://histriabooks.com/wp-content/uploads/2020/02/The-Lost-Diary.jpg"
                                                    alt="" class=" mx-5 py-3 ">
                                            </div>
                                            <div class="col-md-6">
                                                <h1 class="mt-5">The Lost Diary </h1>
                                                
                                                <div class="has-validation-1">
                                                    <h6>The Diary of Anne Frank is a seminal piece of twentieth-century
                                                        literature. It recounts the tragic and moving story of a young
                                                        Jewish teenager faced with the horrors of Nazism. In it, Anne
                                                        establishes a bond with her readers that transcends both time
                                                        and space, making them her friends and confidants.</h6>
                                                        <div class="col-md-6 py-3">
                                                            <a href="bookinfo.php" class="btn btn-default w-100 py-2"><i
                                                                class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                                            
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- modal 3 -->
        <div class="modal fade" id="staticBackdrop2" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg ">
                <div class="modal-content">

                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title fw-bold text-light text-center">Mein Kamph</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <!-- Modal body -->
                    <div class="modal-body">
                        <div class="container">
                            <div class="col-lg-12 col-12 justify-content-center">
                                <div class="row">
                                    <form class="w-100">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <img src="https://n4.sdlcdn.com/imgs/b/m/9/Mein-Kempf-Adolf-Hitler-Paperback-SDL298110638-1-fff4f.jpg"
                                                    alt="" class=" py-3 ">
                                            </div>
                                            <div class="col-md-6">
                                                <h1 class="mt-5">Mein Kamph</h1>
                                                <div class="has-validation-1">
                                                    <h6>Mein Kampf (German: [maɪn ˈkampf]; lit. 'My Struggle') is a 1925
                                                        autobiographical manifesto by Nazi Party leader Adolf Hitler.
                                                        The work describes the process by which Hitler became
                                                        antisemitic and outlines his political ideology and future plans
                                                        for Germany.</h6>
                                                        <div class="col-md-6 py-3">
                                                            <a href="bookinfo.php" class="btn btn-default w-100 py-2"><i
                                                                class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                                            
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- modal 4 -->
        <div class="modal fade" id="staticBackdrop3" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
            aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg ">
                <div class="modal-content">

                    <!-- Modal Header -->
                    <div class="modal-header">
                        <h4 class="modal-title fw-bold text-light text-center">Alice Munro</h4>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <!-- Modal body -->
                    <div class="modal-body">
                        <div class="container">
                            <div class="col-lg-12 col-12 justify-content-center">
                                <div class="row">
                                    <form class="w-100">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <img src="https://m.media-amazon.com/images/W/IMAGERENDERING_521856-T1/images/I/51rmSgxnGLL._SX322_BO1,204,203,200_.jpg"
                                                    alt="" class=" px-5 pt-2 h-100">
                                            </div>
                                            <div class="col-md-6">
                                                <h1 class="mt-5">Alice Munro</h1>
                                               
                                                <div class="has-validation-1">
                                                    <h6>The only novel from Alice Munro -- award-winning author of The
                                                        Love of a Good Woman -- is an insightful, honest book,
                                                        "autobiographical in form but not in fact," that chronicles a
                                                        young girl's growing up in rural Ontario in the 1940s..</h6>
                                                        <div class="col-md-6 py-3">
                                                            <a href="bookinfo.php" class="btn btn-default w-100 py-2"><i
                                                                class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                                            
                                                        </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <section class="feature-courses-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12 text-center mt-5 mb-3">
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-4 col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="courses-main-img ms-4">
                                    <img src="https://m.media-amazon.com/images/W/IMAGERENDERING_521856-T1/images/I/71hAoLQ1+YL.jpg"
                                        alt="Image" class="img-fluid rounded">
                                </div>
                                <div class="courses-content mt-2">
                                    <h6 class="text-center m-0">Agatha Oddly</h6>
                                    <small class="text-sm">By Easy Library</small>
                                    <button class="btn btn-default w-100 mt-3" data-bs-toggle="modal"
                                        data-bs-target="#staticBackdrop4"><i class="fa fa-eye"></i> Read</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-4 col-sm-4 col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="courses-main-img ms-5">
                                    <img src="https://m.media-amazon.com/images/W/IMAGERENDERING_521856-T1/images/I/41tAE1231LL._SX312_BO1,204,203,200_.jpg"
                                        alt="Image" class="img-fluid rounded">
                                </div>
                                <div class="courses-content mt-2">
                                    <h6 class="text-center m-0">The Time Machine</h6>
                                    <small class="text-sm">By Easy Library</small>
                                    <button class="btn btn-default w-100 mt-3" data-bs-toggle="modal"
                                        data-bs-target="#staticBackdrop5"><i class="fa fa-eye"></i> Read</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-4 col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="courses-main-img ms-4">
                                    <img src="https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1615294469i/56138672.jpg"
                                        alt="Image" class="img-fluid rounded">
                                </div>
                                <div class="courses-content mt-2">
                                    <h6 class="text-center m-0">The Girl From Silent Lake</h6>
                                    <small class="text-sm">By EasyTutor</small>
                                    <button class="btn btn-default w-100 mt-3" data-bs-toggle="modal"
                                        data-bs-target="#staticBackdrop6"><i class="fa fa-eye"></i> Read</button>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-4 col-sm-4 col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="courses-main-img ms-5">
                                    <img src="https://m.media-amazon.com/images/W/IMAGERENDERING_521856-T1/images/I/81FWnA3WF1S.jpg"
                                        alt="Image" class="img-fluid rounded">
                                </div>
                                <div class="courses-content mt-4">
                                    <h6 class="text-center m-0">The Canterville Ghost</h6>
                                    <button class="btn btn-default w-100 mt-3" data-bs-toggle="modal"
                                        data-bs-target="#staticBackdrop7"><i class="fa fa-eye"></i> Read</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <div class="feature-courses-area pt-100 pb-70">
            <div class="col-lg-12 py-3 text-center py-5">
                <a href="categories.php" class="text-center fw-bolder" style="color: darkslategray;">Browse All</a>
            </div>
        </div>
    </section>

    <!-- modal 5 -->
    <div class="modal fade" id="staticBackdrop4" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg ">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title fw-bold text-light text-center">Agatha Oddly</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <div class="container">
                        <div class="col-lg-12 col-12 justify-content-center">
                            <div class="row">
                                <form class="w-100">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <img src="https://m.media-amazon.com/images/W/IMAGERENDERING_521856-T1/images/I/71hAoLQ1+YL.jpg"
                                                alt="" class=" px-5 pt-2 ">
                                        </div>
                                        <div class="col-md-6">
                                            <h1 class="mt-5">Agatha Oddly</h1>
                                            
                                            <div class="has-validation-1">
                                                <h6>Meet thirteen-year-old Agatha Oddly – a bold, determined heroine and
                                                    the star of a stylish new detective series.Agatha Oddlow has been a
                                                    detective for as long as she can remember – she’s just been waiting
                                                    for her first big case. And nothing gets bigger than saving the City
                                                    of London from some strange goings-on.</h6>
                                                    <div class="col-md-6 py-3">
                                                        <a href="bookinfo.php" class="btn btn-default w-100 py-2"><i
                                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                                        
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- modal 6 -->
    <div class="modal fade" id="staticBackdrop5" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg ">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title fw-bold text-light text-center">Agatha Oddly</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <div class="container">
                        <div class="col-lg-12 col-12 justify-content-center">
                            <div class="row">
                                <form class="w-100">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <img src="https://m.media-amazon.com/images/W/IMAGERENDERING_521856-T1/images/I/41tAE1231LL._SX312_BO1,204,203,200_.jpg"
                                                alt="" class=" px-5 pt-2 ">
                                        </div>
                                        <div class="col-md-6">
                                            <h1 class="mt-5">The Time Machine</h1>
                                            
                                            <div class="has-validation-1">
                                                <h6>The Time Machine is a post-apocalyptic science fiction novella by H.
                                                    G. Wells, published in 1895. The work is generally credited with the
                                                    popularization of the concept of time travel by using a vehicle or
                                                    device to travel purposely and selectively forward or backward
                                                    through time.</h6>
                                                    <div class="col-md-6 py-3">
                                                        <a href="bookinfo.php" class="btn btn-default w-100 py-2"><i
                                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                                        
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- modal 7 -->
    <div class="modal fade" id="staticBackdrop6" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg ">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title fw-bold text-light text-center">The Girl From Silent Lake</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <div class="container">
                        <div class="col-lg-12 col-12 justify-content-center">
                            <div class="row">
                                <form class="w-100">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <img src="https://images-na.ssl-images-amazon.com/images/S/compressed.photo.goodreads.com/books/1615294469i/56138672.jpg"
                                                alt="" class=" px-5 pt-2 ">
                                        </div>
                                        <div class="col-md-6">
                                            <h1 class="mt-5">The Girl From Silent Lake</h1>
                                            
                                            <div class="has-validation-1">
                                                <h6>“Wow!!!! It simply took my breath away so much that I finished this
                                                    book in one go! Literally took my breath away! I simply couldn’t put
                                                    the book down. Unputdownable.” Tropical Girl Reads Books</h6>
                                                    <div class="col-md-6 py-3">
                                                        <a href="bookinfo.php" class="btn btn-default w-100 py-2"><i
                                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                                        
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- modal 1 -->
    <div class="modal fade" id="staticBackdrop7" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg ">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header">
                    <h4 class="modal-title fw-bold text-light text-center">The Canterville Ghost</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <div class="container">
                        <div class="col-lg-12 col-12 justify-content-center">
                            <div class="row">
                                <form class="w-100">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <img src="https://m.media-amazon.com/images/W/IMAGERENDERING_521856-T1/images/I/81FWnA3WF1S.jpg"
                                                alt="" class="src">
                                        </div>
                                        <div class="col-md-6">
                                            <h1 class="mt-5">The Canterville Ghost</h1>
                
                                            <div class="has-validation-1">
                                                <h6>The story is about an American family who moved to a castle haunted
                                                    by the ghost of a dead English nobleman, who killed his wife and was
                                                    then walled in and starved to death by his wife's brothers.</h6>
                                                    <div class="col-md-6 py-3">
                                                        <a href="bookinfo.php" class="btn btn-default w-100 py-2"><i
                                                            class="fa fa-address-book px-2 text-light"></i>Booking</a>
                                                        
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <!-- footer -->
    <footer class="bg-dark pt-4">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-6 col-12 text-light">
                    <h5>EasyTutorial</h5>
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mattis mi suscipit bibendum sit amet,
                        consectetur.</p>
                </div>
                <div class="col-lg-3 col-sm-6 col-12 text-light">
                    <h5>Quick Link</h5>
                    <ul class="list-unstyled">
                        <li class="">Courses</li>
                        <li class="">About Us</li>
                        <li class="">Terms & Conditions</li>
                    </ul>
                </div>
                <div class="col-lg-3 col-sm-6 col-12 text-light">
                    <h5>Help Center</h5>
                    <ul class="list-unstyled">
                        <li class="">Support</li>
                        <li class="">Get Help</li>
                        <li class="">Privacy Policy</li>
                    </ul>
                </div>
                <div class="col-lg-3 col-sm-6 col-12 text-light">
                    <h5>Contact Info</h5>
                    <ul class="list-unstyled">
                        <li class="">Call Us: +91-8906634065</li>
                        <li class="">Address: 105/5b, Dumdum road, Kolkata-74</li>
                        <li class="">Mail Us: support@softmaker.co.in</li>
                    </ul>
                </div>
                <hr>
                <p class="text-light text-center">EasyLibrary &copy; 2023</p>
            </div>
        </div>
    </footer>


    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/common.js"></script>
    <script>
        $(function () {
            setInterval(function () {
                $('.shape-1').fadeIn(1000).delay(2000).fadeOut(1500).delay(3000).fadeIn(1500);
                $('.shape-2').fadeIn(1000).delay(2000).fadeOut(1500).delay(4000).fadeIn(1500);
                $('.shape-3').fadeIn(1000).delay(2000).fadeOut(1500).delay(5000).fadeIn(1500);
            }, 2000);
        });
    </script>
</body>

</html>