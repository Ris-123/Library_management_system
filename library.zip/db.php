<?php
$hostname = "localhost";
$username = "root";
$password = "";
$dbname = "library";
$connect = mysqli_connect($hostname, $username, $password, $dbname);
if (!$connect) {
    echo "database connection error" . mysqli_connect_error();
}
?>