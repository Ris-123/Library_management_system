<?php
 session_start();
 include('db.php');
 if(!isset($_SESSION['usr'])){
  header('Location: subscribtion.php');
    $profile = '';
    $registration = '<button class="btn btn-default ms-lg-3" type="button" onclick="registr()"><i class="fa fa-user"></i>
    Register Now</button>';
 }
 else{
    $profile = '<li class="nav-item active">
    <a class="nav-link" href="profile.php"><i class="fa fa-user"></i> My Profile</a>
</li>';
    $registration = '<a href="logout.php" class="btn btn-default ms-lg-3" type="button"><i class="fa fa-signout"></i>
    Log Out</a>';
 }
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Easy Library</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="assets/css/main.css">
  <style>
   
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-sm bg-light navbar-light sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Easy Library</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item">
            <a class="nav-link" href="index.php"><i
                class="fa fa-home"></i> Home</a>
          </li>
          <?php echo $profile; ?>
          <li class="nav-item active">
            <a class="nav-link" href="contact_us.php"><i class="fa fa-phone"></i> Contact Us</a>
          </li>
        </ul>
        <?php echo $registration; ?>
        
      </div>
    </div>
  </nav>

  <div class="banner-area py-5">
    <div class="container">
      <div class="page-banner-content">
        <h2 class="text-center">Booking Confirmation</h2>
        <ul class="list-inline w-100 mx-auto">
          <li class="list-inline-item">
            <a class="text-decoration-none text-light"
              href="index.php">Home</a>
          </li>
          <li class="list-inline-item">Booking</li>
        </ul>
      </div>
    </div>
  </div>

  <div class="row">
    <div class="col-100">
      <div class="container">
        <div class="col-8 offset-2">
        <div class="card mt-5">
          <div class="card-body">
            <form action="action.php" method="post">

              <div class="row">
                <div class="col-12">
                  <h3 class="mt-3">BOOKING</h3>
                  <div class="text-area mt-3">
                  <label for="fname"><i class="fa fa-book px-1"></i> Book Title</label>
                  <input type="text"  name="booktitle" placeholder="Book Title">
                  <label for="email"><i class="fa fa-user px-1"></i>Editor's Name</label>
                  <input type="text"  name="editorname" placeholder="Editor's Name">
                  <label for="days"><i class="fa fa-calendar px-1"></i> Number of Days</label>
                  <input type="text"  name="days" placeholder="The Number Of Days">
                  <label for="city"><i class="fa fa-code px-1"></i>Book Code</label>
                  <input type="text"  name="bookcode" placeholder="Book Code">
                  <label for="state"><i class="fa fa-address-book px-1"></i>The Name Of Library</label>
                  <input type="text"  name="libname" placeholder="The Name Of Library">
                  <label for="state"><i class="fa fa-list-ol px-1"></i>Token No</label>
                  <input type="text"  name="tokenno" placeholder="Token No">
                  </div>
                </div>
              </div>
              <div class="col-md-12 py-3">
                <button type="submit" class="btn btn-default w-100 py-2"><i
                    class="fa fa-address-book px-2 text-light fw-bolder"></i>CONFIRM</button>
                
            </div>
            </form>
          </div>
        </div>
        </div>
      </div>
    </div>
  </div>

                 

 

  <footer class="bg-dark pt-4 mt-5 ">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-sm-6 col-12 text-light">
          <h5>EasyTutorial</h5>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mattis mi suscipit bibendum sit amet,
            consectetur.</p>
        </div>
        <div class="col-lg-3 col-sm-6 col-12 text-light">
          <h5>Quick Link</h5>
          <ul class="list-unstyled">
            <li class="">Courses</li>
            <li class="">About Us</li>
            <li class="">Terms & Conditions</li>
          </ul>
        </div>
        <div class="col-lg-3 col-sm-6 col-12 text-light">
          <h5>Help Center</h5>
          <ul class="list-unstyled">
            <li class="">Support</li>
            <li class="">Get Help</li>
            <li class="">Privacy Policy</li>
          </ul>
        </div>
        <div class="col-lg-3 col-sm-6 col-12 text-light">
          <h5>Contact Info</h5>
          <ul class="list-unstyled">
            <li class="">Call Us: +91-8906634065</li>
            <li class="">Address: 105/5b, Dumdum road, Kolkata-74</li>
            <li class="">Mail Us: support@softmaker.co.in</li>
          </ul>
        </div>
        <hr>
        <p class="text-light text-center">EasyLibrary &copy; 2023</p>
      </div>
    </div>
  </footer>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/common.js"></script>

</body>

</html>