function registr(){
    location.assign('subscribtion.php');
}

$(document).ready(function() {
 
    $("#owl-demo").owlCarousel({
      navigation : true
    });
   
  });
  


