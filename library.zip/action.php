<?php
session_start();
include('db.php');

if (isset($_POST['nam'])) {
    $name = $_POST['nam'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    mysqli_query($connect, "INSERT INTO `contact`(`id`, `name`, `email`, `subject`, `message`) VALUES (null,'$name','$email','$subject','$message')");
    header('Location: contact_us.php');
}


if (isset($_POST['first_name'])) {
    $firstname = $_POST['first_name'];
    $lastname = $_POST['last_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    mysqli_query($connect, "INSERT INTO `subscribtion`(`id`, `firstname`, `lastname`, `email`, `phone`, `address`, `city`, `state`, `pin`, `password`) VALUES (null,'$firstname','$lastname','$email','','','','','','$password')");
    header('Location: subscribtion.php');
}


if (isset($_POST['email'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $verify = mysqli_query($connect, "SELECT * FROM `subscribtion` WHERE `email`= '$email' AND `password`= '$password'");
    if (mysqli_num_rows($verify) > 0) {
        $_SESSION['usr'] = $email;
        header('Location: index.php');
    } else {
        echo '<script>alert("credential mismatched!!");</script>';
    }
}

if (isset($_POST['booktitle'])) {
    $booktitle = $_POST['booktitle'];
    $editorname = $_POST['editorname'];
    $days = $_POST['days'];
    $bookcode = $_POST['bookcode'];
    $libname = $_POST['libname'];
    $tokenno = $_POST['tokenno'];

    mysqli_query($connect, "INSERT INTO `bookinfo`(`id`, `booktitle`, `editorname`, `days`, `bookcode`, `libname`, `tokenno`) VALUES ('null','$booktitle','$editorname','$days','$bookcode','$libname','$tokenno')");
    header('Location: bookinfo.php');

}

if (isset($_POST['epid'])) {
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $pin = $_POST['pin'];
    $eimg = $_POST['eimg'];
    $epid = $_POST['epid'];

    mysqli_query($connect, "UPDATE `subscribtion` SET `firstname`='$firstname',`lastname`='$lastname',`phone`='$phone',`address`='$address',`city`='$city',`state`='$state',`pin`='$pin' WHERE `id` = '$epid'");

    if(isset($_FILES['picture'])){
        $img_name=$_FILES['picture']['name'];
        $img_type=$_FILES['picture']['type'];
        $tmp_name=$_FILES['picture']['tmp_name'];
        $img_explode=explode('.', $img_name);
        $img_ext=end($img_explode);
        $extentions=["jpeg","png","jpg"];
        if(in_array($img_ext, $extentions)===true){
            if(move_uploaded_file($tmp_name,"assets/profile/".$img_name)){
                mysqli_query($connect,"UPDATE `subscribtion` SET `img`='$img_name' WHERE `id`='$epid'");
            }
        }
    }
    header('Location: profile.php');

}
?>