<?php
session_start();
include('db.php');
if (!isset($_SESSION['usr'])) {
  header('Location: subscribtion.php');
  $profile = '';
  $registration = '<button class="btn btn-default ms-lg-3" type="button" onclick="registr()"><i class="fa fa-user"></i>
    Register Now</button>';
} else {
  $profile = '<li class="nav-item active"> <a class="nav-link" href="profile.php"><i class="fa fa-user"></i> My Profile</a> </li>';
  $registration = '<a href="logout.php" class="btn btn-default ms-lg-3" type="button"><i class="fa fa-signout"></i>
    Log Out</a>';

  $prof = mysqli_query($connect, "SELECT * FROM `subscribtion` WHERE `email` = '" . $_SESSION['usr'] . "'");
  $pf = mysqli_fetch_assoc($prof);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://unpkg.com/tailwindcss@^1.0/dist/tailwind.min.css" rel="stylesheet">

  <title>E-DAMY</title>
  <link href="owl-carousel/owl.carousel.css" rel="stylesheet">
  <link href="owl-carousel/owl.theme.css" rel="stylesheet">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="assets/css/main.css">
  <style>
    .card {
      border-radius: 15px;
      background: #f1e6e6a6;
    }

    .Theme {
      background: linear-gradient(315deg, #099940, #057fa8);
      background-size: 100% 100%;
      background-attachment: fixed;
      background-repeat: no-repeat;
      width: 100%;
      height: 100%;
    }

    .btn-outline-primary {
      font-size: small;
      border-radius: 10px;
    }

    .btn-primary {
      border-radius: 15px;
      font-size: large;

    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-sm bg-light navbar-light sticky-top">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Easy Library</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="collapsibleNavbar">
        <ul class="navbar-nav ms-auto">
          <li class="nav-item active">
            <a class="nav-link" href="index.php"><i class="fa fa-home"></i> Home</a>
          </li>
          <?php echo $profile; ?>
          <li class="nav-item active">
            <a class="nav-link" href="contact_us.php"><i class="fa fa-phone"></i> Contact Us</a>
          </li>
        </ul>
        <?php echo $registration; ?>

      </div>
    </div>
  </nav>


  <section class="Theme">
    <div class="container py-5 h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class=" col-md-12">
          <div class="card">
            <div class="card-body p-4 h-100">
              <div class="d-flex text-black">
                <div class="flex-shrink-0 col-2">
                  <?php 
                  if($pf['img']!=''){
                  ?>
                  <img src="assets/profile/<?php echo $pf['img']; ?>" alt="Generic placeholder image">
                  <?php
                  }
                  else{
                  ?>
                  <img src="assets/demo.jpg" alt="Generic placeholder image">
                  <?php } ?>
                  <div class=" col-12 text-center mt-2">
                    <button type="button" class="btn btn-outline-primary font-mono w-100"
                      onclick="uploadpic()">Upload</i></button>
                  </div>

                </div>
                <div class="col-10">
                  <form action="action.php" method="post" enctype="multipart/form-data">
                    <input type="file" name="picture" id="cprofile" hidden>
                    <input type="text" name="epid" value="<?php echo $pf['id']; ?>" hidden>
                    <input type="text" name="eimg" value="<?php echo $pf['img']; ?>" hidden>
                    <div class="row ms-1 h-100">
                      <div class="col-md-6">
                        <label>First Name</label>
                        <input type="text" name="firstname" class="form-control form-control-sm"
                          value="<?php echo $pf['firstname']; ?>" placeholder="First Name" required>
                      </div>
                      <div class="col-md-6">
                        <label>Last Name</label>
                        <input type="text" name="lastname" class="form-control form-control-sm"
                          value="<?php echo $pf['lastname']; ?>" placeholder="Last Name" required>
                      </div>
                      <div class="col-md-6">
                        <label>Email Id</label>
                        <input type="text"  class="form-control form-control-sm"
                          value="<?php echo $pf['email']; ?>" placeholder="Emil Id" disabled>
                      </div>
                      <div class="col-md-6">
                        <label>Phone No</label>
                        <input type="text" name="phone" class="form-control form-control-sm"
                          value="<?php echo $pf['phone']; ?>" placeholder="Phone No" required>
                      </div>
                      <div class="col-md-12 mb-2">
                        <label>Address</label>
                        <textarea rows="4" name="address" class="form-control" placeholder="Address"
                          required><?php echo $pf['address']; ?></textarea>
                      </div>
                      <div class="col-md-4">
                        <label>City</label>
                        <input type="text" name="city" class="form-control form-control-sm"
                          value="<?php echo $pf['city']; ?>" placeholder="City" required>
                      </div>
                      <div class="col-md-4">
                        <label>State</label>
                        <input type="text" name="state" class="form-control form-control-sm"
                          value="<?php echo $pf['state']; ?>" placeholder="State" required>
                      </div>
                      <div class="col-md-4">
                        <label>Pincode</label>
                        <input type="text" name="pin" class="form-control form-control-sm"
                          value="<?php echo $pf['pin']; ?>" placeholder="Pincode" required>
                      </div>
                      <div class="col-md-12">
                        <button type="submit" class="btn btn-primary w-100">Edit Profile</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

  </section>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/common.js"></script>

  <script>
    $(function () {
      setInterval(function () {
        $('.shape-1').fadeIn(1000).delay(2000).fadeOut(1500).delay(3000).fadeIn(1500);
        $('.shape-2').fadeIn(1000).delay(2000).fadeOut(1500).delay(4000).fadeIn(1500);
        $('.shape-3').fadeIn(1000).delay(2000).fadeOut(1500).delay(5000).fadeIn(1500);
      }, 2000);
    });
  </script>

  <script>
    function uploadpic() {
      $('#cprofile').click();
    }
  </script>
</body>

</html>